User activity artifacts were extracted from a windows profile.
